package com.prajwal.dependencyInjection;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DependencyInjectionApplicationTests {

	@Test
	void contextLoads() {
	}

}
